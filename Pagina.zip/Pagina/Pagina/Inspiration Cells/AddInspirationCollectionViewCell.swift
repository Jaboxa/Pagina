//
//  AddInspirationCollectionViewCell.swift
//  Pagina
//
//  Created by user on 2/11/18.
//  Copyright © 2018 dogbird. All rights reserved.
//

import UIKit

class AddInspirationCollectionViewCell: UICollectionViewCell {
    
}
